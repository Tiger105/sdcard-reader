/*------------------------------------------------------------------------------
 * MDK Middleware - Component ::USB:Device
 * Copyright (c) 2004-2015 ARM Germany GmbH. All rights reserved.
 *------------------------------------------------------------------------------
 * Name:    MassStorage.c
 * Purpose: USB Device - Mass Storage example
 *----------------------------------------------------------------------------*/

#include "cmsis_os.h"                   /* CMSIS RTOS definitions             */
#include "rl_fs.h"                      /* FileSystem definitions             */
#include "rl_usb.h"                     /* RL-USB function prototypes         */
//#include "stm32f10x.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"

GPIO_InitTypeDef GPIO_InitStruct_out;
GPIO_InitTypeDef GPIO_InitStruct_in;

uint8_t mode = 0;
uint8_t btn = 0;
uint8_t switchPin = 0;
uint8_t initmode = 1;
uint8_t currentmode =0;
uint8_t flag = 0;

void GPIO_initalize();
void modeSwitch();
void modeSwitch1();

int main (void) {

	//GPIO_initalize();
	
  finit          ("M0:");               /* Initialize SD Card 0               */
  fmount         ("M0:");               /* Mount SD Card 0                    */

  USBD_Initialize(0);                   /* USB Device 0 Initialization        */
  USBD_Connect   (0);                   /* USB Device 0 Connect               */

  while (1) {
   // modeSwitch();
		osDelay(1000);
  }
}

void GPIO_initalize()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStruct_out.GPIO_Pin = GPIO_Pin_4;
	GPIO_InitStruct_out.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStruct_out.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStruct_out);	
	
	//RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStruct_in.GPIO_Pin = GPIO_Pin_5;
	GPIO_InitStruct_in.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStruct_in.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOA, &GPIO_InitStruct_in);	
}

void modeSwitch()
{
  btn = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5);
  currentmode = btn;
  if(btn == 0 && flag == 0){
    flag = 1;
  } 
	//osDelay(10);
  if((btn  == 1) && (flag == 1)){
    if(mode ==0){
      mode=1;
    }else{
      mode=0;
    }
    flag = 0;
  }
  //else {
  //}
  if(mode == 0){  
    GPIO_ResetBits(GPIOA, GPIO_Pin_4);
  }
  else{
    GPIO_SetBits(GPIOA, GPIO_Pin_4);
  } 
}

void modeSwitch1()
{
	btn = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5);
	if(btn == 1 && flag == 0)
	{
		flag = 1;
		GPIO_SetBits(GPIOA, GPIO_Pin_4);
	}
	else if(btn == 1 && flag == 1 )
	{
		flag = 0;

		
	}
	if(flag == 1)
	{
		GPIO_SetBits(GPIOA, GPIO_Pin_4);
		flag = 0;
	}else{
		GPIO_ResetBits(GPIOA, GPIO_Pin_4);
		flag = 1;
	}
}
